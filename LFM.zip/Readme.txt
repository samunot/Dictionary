Java

1. Compile driver.java
2. Run driver.java and give the test file as argument. eg: java driver.java testFile.txt

Python

1. Run driver.py
2. If you want to modify the testfile, edit the last line of driver.py